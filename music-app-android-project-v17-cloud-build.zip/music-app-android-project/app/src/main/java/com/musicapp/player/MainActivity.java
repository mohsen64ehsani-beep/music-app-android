package com.musicapp.player;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.net.URL;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,13,23));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,13,23));
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportMultipleWindows(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new NativeDownloader(this), "AndroidDownloader");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                // Keep the bundled app local; external top-level navigation is opened by Android browser.
                if ("file".equals(scheme) || "https".equals(scheme) || "http".equals(scheme)) {
                    String host = uri.getHost();
                    if ("file".equals(scheme) || host == null || host.equals("dzrlguwrqabtfnhfpgjo.supabase.co")) return false;
                    if (request.isForMainFrame()) {
                        try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, uri)); return true; }
                        catch (Exception ignored) { return false; }
                    }
                    return false;
                }
                return true;
            }
        });
        webView.setDownloadListener(new DownloadListener() {
            @Override public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
                new NativeDownloader(MainActivity.this).downloadMedia(url, fileNameFromDisposition(contentDisposition, mimeType));
            }
        });
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }

    private String fileNameFromDisposition(String disposition, String mime) {
        if (disposition != null && disposition.contains("filename=")) {
            String n = disposition.substring(disposition.indexOf("filename=") + 9).replace("\"", "").trim();
            if (!n.isEmpty()) return n;
        }
        return (mime != null && mime.startsWith("video/")) ? "music-video.mp4" : "music.mp3";
    }

    public class NativeDownloader {
        private final Context context;
        NativeDownloader(Context c) { context = c.getApplicationContext(); }

        @JavascriptInterface public void downloadMedia(String url, String filename) {
            runOnUiThread(() -> enqueue(url, filename));
        }

        private void enqueue(String rawUrl, String rawName) {
            try {
                Uri uri = Uri.parse(rawUrl);
                String scheme = uri.getScheme();
                if (scheme == null || !(scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http"))) {
                    Toast.makeText(context, "لینک دانلود معتبر نیست", Toast.LENGTH_LONG).show(); return;
                }
                String name = (rawName == null || rawName.trim().isEmpty()) ? "music-download" : rawName.replaceAll("[\\\\/:*?\"<>|]", "_");
                DownloadManager.Request request = new DownloadManager.Request(uri);
                request.setTitle(name);
                request.setDescription("در حال دانلود از آپ موزیک");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setAllowedOverMetered(true);
                request.setAllowedOverRoaming(true);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                request.setMimeType(name.toLowerCase().endsWith(".mp4") ? "video/mp4" : "audio/mpeg");
                String cookie = CookieManager.getInstance().getCookie(rawUrl);
                if (cookie != null) request.addRequestHeader("Cookie", cookie);
                request.addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome Mobile Safari/537.36");
                DownloadManager manager = (DownloadManager) context.getSystemService(DOWNLOAD_SERVICE);
                manager.enqueue(request);
                Toast.makeText(context, "دانلود در پس‌زمینه شروع شد؛ اعلان گوشی را بررسی کن", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(context, "شروع دانلود ناموفق بود: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) { webView.saveState(outState); super.onSaveInstanceState(outState); }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}
